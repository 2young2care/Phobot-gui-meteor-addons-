package me.earth.meteorpb.keyboard;

// TODO: once we have the functionality in Pingbypass use this to listen for remote KeyEvents and toggle modules
public class RemoteKeyEventListener {

}
